/** @license See the LICENSE file. */

// This code is auto-generated, do not modify this file!
const version = '2.2.1';
export {version};
